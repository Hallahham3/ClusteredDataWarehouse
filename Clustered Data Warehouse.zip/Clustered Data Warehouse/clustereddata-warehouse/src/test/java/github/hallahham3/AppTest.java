package github.hallahham3;

import static org.junit.Assert.assertTrue;

import java.math.BigDecimal;
import java.sql.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class AppTest {

    private static final String TEST_DB_URL = "jdbc:mysql://localhost:3306/Clustered_Data_Warehouse";
    private static final String TEST_DB_USERNAME = "root";
    private static final String TEST_DB_PASSWORD = "0000";

    private Connection connection;

    @Before
    public void setUp() throws SQLException {
        connection = DriverManager.getConnection(TEST_DB_URL, TEST_DB_USERNAME, TEST_DB_PASSWORD);
    }

    @After
    public void tearDown() throws SQLException {
        if (connection != null) {
            connection.close();
        }
    }

    @Test
    public void testInsertDeal() throws SQLException {
        String dealUniqueId = "123456";
        String fromCurrencyISOCode = "USD";
        String toCurrencyISOCode = "EUR";
        Timestamp dealTimestamp = new Timestamp(System.currentTimeMillis());
        BigDecimal dealAmount = new BigDecimal("1000.50");

        // Insert the deal into the test table
        insertDealIntoTestTable(dealUniqueId, fromCurrencyISOCode, toCurrencyISOCode, dealTimestamp, dealAmount);

        // Verify that the deal exists in the test table
        assertTrue("Deal should be inserted successfully", isDealInserted(dealUniqueId));
    }

    private void insertDealIntoTestTable(String uniqueId, String fromCurrency, String toCurrency, Timestamp timestamp, BigDecimal amount) throws SQLException {
        String query = "INSERT INTO deals (dealUniqueId, fromCurrencyISOCode, toCurrencyISOCode, dealTimestamp, dealAmount) " +
                "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, uniqueId);
            statement.setString(2, fromCurrency);
            statement.setString(3, toCurrency);
            statement.setTimestamp(4, timestamp);
            statement.setBigDecimal(5, amount);
            statement.executeUpdate();
        }
    }

    private boolean isDealInserted(String uniqueId) throws SQLException {
        String query = "SELECT COUNT(*) FROM deals WHERE dealUniqueId = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, uniqueId);
            try (ResultSet resultSet = statement.executeQuery()) {
                resultSet.next();
                return resultSet.getInt(1) > 0;
            }
        }
    }
}
