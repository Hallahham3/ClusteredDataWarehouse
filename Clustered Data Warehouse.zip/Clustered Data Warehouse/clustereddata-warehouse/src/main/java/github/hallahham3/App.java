package github.hallahham3;

import java.sql.SQLException; 
import java.util.logging.Level; 
import java.util.logging.Logger;

public class App {

    // Main method
    public static void main(String[] args) {
        DatabaseConnection dbConnection = new DatabaseConnection();
        
        final Logger LOGGER = Logger.getLogger(RequestHandling.class.getName());

        String DB_URL = "jdbc:mysql://localhost:3306/Clustered_Data_Warehouse";
        String DB_UserName = "root";
        String DB_Password = "0000";

        try {
            dbConnection.connect(DB_URL, DB_UserName, DB_Password);
        } catch (SQLException e) { 
            e.printStackTrace();
            LOGGER.log(Level.SEVERE, "Failed to establish connection to the database");
        } finally { 
            try {
                dbConnection.disconnect();
            } catch (SQLException e) { 
                e.printStackTrace();
                LOGGER.log(Level.SEVERE, "Failed to disconnect from the database");
            }
        }
    }
}
