      CREATE TABLE Deal (
       DealId  INT NOT NULL,
       FromCurrencyISOCode VARCHAR(50) NOT NULL,
       ToCurrencyISOCode VARCHAR(50) NOT NULL,
       DealTimestamp TIMESTAMP NOT NULL,
       DealAmount NUMERIC NOT NULL,
       CONSTRAINT [PK_Deal] PRIMARY KEY CLUSTERED ([DealId] ASC)
   );